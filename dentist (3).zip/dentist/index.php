<?php

// $conn = mysqli_connect('localhost','root','','contact_db') or die('connection failed');

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $date = $_POST['date'];

   $insert = mysqli_query($conn, "INSERT INTO `contact_form`(name, email, number, date) VALUES('$name','$email','$number','$date')") or die('query failed');

   if($insert){
      $message[] = 'appointment made successfully!';
   }else{
      $message[] = 'appointment failed';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Ekdant Dental Clinic</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- bootstrap cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<!-- header starts  -->

<header class="header fixed-top">

   <div class="container">

      <div class="row align-items-center justify-content-between">

         <a href="#home" class="logo">Ekdant<span> Dental Care.</span></a>

         <nav class="nav">
            <a href="#home">home</a>
            <a href="#about">about</a>
            <a href="#services">services</a>
            <a href="#reviews">reviews</a>
            <a href="#contact">contact</a>
         </nav>

         <a href="#contact" class="link-btn">make appointment</a>

         <div id="menu-btn" class="fas fa-bars"></div>

      </div>

   </div>

</header>

<!-- header ends -->

<!-- home starts  -->

<section class="home" id="home">

   <div class="container">

      <div class="row min-vh-100 align-items-center">
         <div class="content text-center text-md-left">
            <h3>Creating Vibrant Smiles!</h3>
            <p>The world always looks brighter from behind a smile</p>
            <a href="#contact" class="link-btn">make appointment</a>
         </div>
      </div>

   </div>

</section>

<!-- home ends -->

<!-- about starts  -->

<section class="about" id="about">

   <div class="container">

      <div class="row align-items-center">

         <div class="col-md-6 image">
            <img src="images/Kids-Dental.jpg" class="w-100 mb-5 mb-md-0 h=2rem" alt="">
         </div>

         <div class="col-md-6 content">
            <span>about us</span>
            <h3>True Healthcare For Your Family</h3>
            <p>Ekdant Dental Clinic is a multi-specialty hospital that provides various kinds of dental treatments since 2004. The clinic is located in the heart of the city.
               <p> We provide high-class treatment at very affordable cost while following proper sterilization and disinfection protocols. The ambience of the clinic is very pleasant and well-ventilated with ample room from fresh air and light.
               The expert team at Ekdant Dental Clinic comprises of leading and experienced Dentists and Specialists from all the branches providing treatment of International Standards.!</p></p>
            <a href="#contact" class="link-btn">make appointment</a>
         </div>

      </div>

   </div>

</section>

<!-- about ends -->

<!-- services starts  -->

<section class="services" id="services">

   <h1 class="heading">our services</h1>

   <div class="box-container container">
      
   <div class="box">
         <img src="images/icon-6.svg" alt="">
         <h3>Cavity inspection</h3>
         <p>A Cavity is a small depression on the chewing surface of the teeth. Normally cavities are occurred due to improper cleaning of teeth, frequently eating junk food and sugary drinks, that create cavities.</p>
      </div>

      <div class="box">
         <img src="images/icon-4.svg" alt="">
         <h3>Root canal Treatment</h3>
         <p>Root canal treatment is carried out in cases where the tooth decay or fracture is very deep and involving the pulp. The pulp is the soft center of the tooth having nerve endings responsible for causing pain and other sensation. 
            In simple terms, it means the removal of the infected or damaged pulp tissue within the tooth and replacement by the artificial biocompatible inert filling material.</p>
      </div>

      <div class="box">
         <img src="images/icon-2.svg" alt="">
         <h3>Orthognathic Surgeries</h3>
         <p>Also known as Corrective Jaw Surgery is carried out to correct conditions of the jaw and face that lead to skeletal disharmonies. This surgery is helpful to adjust a wrongly aligned bite due to abnormal growth of the jaw. 
         To correct different conditions affecting the overall symmetry of your face.</p>
      </div>

      <div class="box">
         <img src="images/icon-3.svg" alt="">
         <h3>Teeth Whitening</h3>
         <p>Don't feel awkward about stained, dull teeth. We have super-class Teeth Whitening Treatment that makes your dream of a stunning white smile a reality.</p>
      </div>

      <div class="box">
         <img src="images/icon-1.svg" alt="">
         <h3>Braces / Orthodontic Treatment</h3>
         <p>Braces / Orthodontic Treatment are for those who want to correct their smile's symmetry. All abnormalities in tooth-like crooked, spaced, or crowded teeth, etc can be corrected and aligned by braces. 
            The final result after Braces enhances your smile and gives a boost to your personal and professional life.</p>
      </div>

      <div class="box">
         <img src="images/icon-5.svg" alt="">
         <h3>Wisdom Teeth Surgery</h3>
         <p>Wisdom tooth surgery is recommended in cases of decayed, un-erupted, or wrongly erupting last molar teeth. 
            Symptoms of the above may be a pain while opening their mouth or chewing food, severe or dull nagging toothache, ear/jaw pain, difficulty in eating due to swelling of gums around the tooth.</p>
      </div>

   </div>

</section>

<!-- services ends -->

<!-- Process starts  -->


<section class="process">

   <h1 class="heading">Why Choose Us?</h1>

   <div class="box-container container">

      <div class="box">
         <img src="images/process-1.png" >
         <h3>High Standard of Dentistry</h3>
         <p>We provide comprehensive treatment planning and follow strict standards that ensure your dental procedure will go smoothly and provide the results you desire.</p>
      </div>

      <div class="box">
         <img src="images/process-2.png" alt="">
         <h3>Committed Dental Team</h3>
         <p>Our administrative and clinical team is second to none. They are experienced, highly trained, friendly, and intuitive regarding your needs and will make your visits run effectively.</p>
      </div>

      <div class="box">
         <img src="images/process-3.png" alt="">
         <h3>Modern Equipment</h3>
         <p>We have a high attention to detail when it comes to our work and invested heavily in their instruments and equipment to give patients the best possible care and treatment.</p>
      </div>

   </div>

</section>

<!-- process ends -->

<!-- reviews starts  -->

<section class="reviews" id="reviews">

   <h1 class="heading"> satisfied clients </h1>

   <div class="box-container container">

      <div class="box">
         <img src="images/customer1.jpg" alt="">
         <p>Highly recommended dental clinic in Sambhajinagar. Extraordinary facilities with highly skilled & knowledgeable dentists, you can always rely on this dental clinic. 
            I was there for my treatment & it was really a great experience.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Niraj Sanghai</h3>
         <span>satisfied client</span>
      </div>

      <div class="box">
         <img src="images\cutomer3.jpg" alt="">
         <p>Doctors were caring, kind, patient, compassionate, and excellent service. I felt safe in the Doctors hands A great dentist! Thanks for your treatment and thanks also to your friendly staff.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Jyotsna Phadke</h3>
         <span>satisfied client</span>
      </div>

      <div class="box">
         <img src="images/customer2.jpg" alt="">
         <p>My treatment was wonderful. I had no more than a moment of discomfort, and absolutely no pain. It was most reassuring to overhear comments to by the professors about her proficiency.
             It felt like we were all on a team together, and we were victorious.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Tushar Patil</h3>
         <span>satisfied client</span>
      </div>

   </div>

</section>

<!-- reviews ends -->

<!-- contact starts -->

<section class="contact" id="contact">

   <h1 class="heading">make appointment</h1>

   <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
      <?php 
         if(isset($message)){
            foreach($message as $message){
               echo '<p class="message">'.$message.'</p>';
            }
         }
      ?>
      <span>your name :</span>
      <input type="text" name="name" placeholder="Enter Your Name" class="box" required>
      <span>your email :</span>
      <input type="email" name="email" placeholder="Enter Your Email" class="box" required>
      <span>your number :</span>
      <input type="number" name="number" placeholder="Enter Your Number" class="box" required>
      <span>Appointment Date :</span>
      <input type="datetime-local" name="date" class="box" required>
      <input type="submit" value="make appointment" name="submit" class="link-btn">

      

   </form>  

</section>

<!-- contact ends -->

<!-- footer starts  -->

<section class="footer">

   <div class="box-container container">

      <div class="box">
         <i class="fas fa-phone"></i>
         <h3>phone number</h3>
         <p>+91-7558-71-1851</p>
      </div>
      
      <div class="box">
         <i class="fas fa-map-marker-alt"></i>
         <h3>our address</h3>
         <p>Chhatrapati Sambhajinagar, India - 431001</p>
      </div>

      <div class="box">
         <i class="fas fa-clock"></i>
         <h3>opening hours</h3>
         <p>11:00am to 10:00pm</p>
      </div>

      <div class="box">
         <i class="fas fa-envelope"></i>
         <h3>email address</h3>
         <p>keleomkar610@gmail.com</p>
      </div>

   </div>

   <div class="credit"> &copy; copyright @ <?php echo date('Y'); ?> by <span>Omkar Kele</span></div>

</section>

<!-- footer ends -->










<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>